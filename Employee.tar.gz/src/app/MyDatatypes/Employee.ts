export interface Employee {
  name: string;
  joindate: string;
  email: string;
  position: string;
}
