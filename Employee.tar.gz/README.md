Employee Management system

Using the project in local steps-> 
1) clone the repo to your machine (git clone)
2) install the dependencies (npm install)
3) serve the project (ng serve)

Kindly check if your machine has node installed and angular isntalled

**--------copy these commands
git clone REPO_NAME
npm install
ng serve 

** This project uses angular 18, so it consists of standalone components.

**Angular Project for Features**
Add Employee
View All employee
Edit employee
